
var bird;
var pipes = [];
var score=0;
function setup() {
  createCanvas(1000, 1000);
  bird = new Bird();
  pipes.push(new Pipe());
}

function draw() {
  background(0);

  for (var i = pipes.length-1; i >= 0; i--) {
    pipes[i].show();
    pipes[i].update();

    if (pipes[i].hits(bird)) {
 //    console.log(score);
 window.location.assign("gameover.html");
     	
    }



    if (pipes[i].offscreen()) {
      pipes.splice(i, 1);
    }


  }

  bird.update();
  bird.show();

  if (frameCount % 100== 0) {
    pipes.push(new Pipe());
    score=score+1;
  }



}

function keyPressed() {
  if (key == ' ') {
    bird.up();
    //console.log("SPACE");
  }
}