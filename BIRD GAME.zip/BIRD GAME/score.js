
<script>
document.getElementbyId("p1").innerHTML=score;
</script>
