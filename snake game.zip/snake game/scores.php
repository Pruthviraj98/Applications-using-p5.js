<!doctype html>
<html>
<?php

$username="admin";
$password="password";
$conn=@mysql_connect("127.0.0.1:3307", "root", "");
@mysql_select_db("scores");
$result = mysql_query("SELECT * FROM ss");
$row=mysql_fetch_assoc($result);

?>
/*<?php

$username="id2786066_halfblood@2a02:4780:bad:c0de::14";
$password="pruthvi98";
$conn=@mysql_connect("localhost", "id2786066_halfblood@2a02:4780:bad:c0de::14", "pruthvi98");
@mysql_select_db("id2786066_scores");
$result = mysql_query("SELECT * FROM scoreofplayer");
$row=mysql_fetch_assoc($result);

?>*/
<head>
<center>
<h1>THE GLOBAL SCORES </h1>
</center>
</head>
<body>
<br><br>
<center> <font size="6"><u>SCORES:</u></font><br> </br></center>
<br>
<table>
<tr>
<td> Player Name </td>
<td> Score </td>
</tr>
<?php
do
{
	echo "<tr>";
	echo "<td>".$row['playername']."</td>";
	echo "<td>".$row['Score']."</td>";
	echo "</tr>";
}while($row=mysql_fetch_assoc($result));
?>
</body>
</html>